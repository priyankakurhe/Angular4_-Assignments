import { Component } from '@angular/core';
type MenuItems = Array<{ name: string}>;
export const MyMenu: MenuItems = [
  {name: 'Home' },
  { name: 'Projects' },
  {name: 'Services' },
  {  name: 'Contact' },
 
];
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'AssignTwoBinding';
  menuItems = MyMenu ;
 selectedItem: MenuItems;
 isVisible = true;
 showSelectedItem = false;
  onSelect(item: MenuItems): void {
    this.selectedItem = item;
    this.isVisible = false;
    this.showSelectedItem = true;

  }
}
