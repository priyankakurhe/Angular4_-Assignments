import { Component, ViewChild, ElementRef } from '@angular/core';
import {style, animate, AnimationBuilder} from '@angular/animations'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AssignFourAnimation';
  @ViewChild('el') el: ElementRef;
  @ViewChild('el1') el1: ElementRef;
  @ViewChild('el2') el2: ElementRef;

  private count =0;
  public isVisible = true;
  private player;  private player1; private player2;

  private factory = this.animationBuilder.build([ 
    style({left: 'translateX(0px)'}),
    animate('3000ms ease-out', style({transform: 'translateX(1300px)'}))
  
]);
private factory1 = this.animationBuilder.build([ 
  style({left: 'translateX(0)'}),
  animate('3000ms 500ms ease-out', style({transform: 'translateX(1300px)', display:'none'}))

]);
private factory2 = this.animationBuilder.build([ 
  style({left: 'translateX(0px)', display:'block'}),
  animate('3000ms 1000ms ease-out', style({transform: 'translateX(1300px)'}))

]);
  constructor(private animationBuilder: AnimationBuilder) { }
 
 
  ngOnInit() {
    this.isVisible = true;
      this.player = this.factory.create(this.el.nativeElement, {});   
      this.player1 = this.factory1.create(this.el1.nativeElement, {});
      this.player2 = this.factory2.create(this.el2.nativeElement, {});

      this.player.play();
      this.player1.play();
      this.player2.play();
        setTimeout(() => {
          this.player.pause();
          }, 500);
          setTimeout(() => {
            this.player1.pause();
            }, 1000);
            setTimeout(() => {
              this.player2.pause();
              setInterval(() => {
              this.count++;
              if (this.count==1)  this.player2.play();
              if (this.count==2)  this.player1.play();
              if (this.count==3)  {this.player.play();
              clearInterval();
             }
             
              }, 1000); 
          }, 1500);
          
         
          this.player.onDone = pauseanimate(this);

  }
  
 
}
function pauseanimate(_this){
  _this.isVisible=false;
}

