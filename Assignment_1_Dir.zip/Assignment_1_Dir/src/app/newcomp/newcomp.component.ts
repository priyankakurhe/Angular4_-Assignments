import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './newcomp.component.html',
  styleUrls: ['./newcomp.component.css']
})
export class NewcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
