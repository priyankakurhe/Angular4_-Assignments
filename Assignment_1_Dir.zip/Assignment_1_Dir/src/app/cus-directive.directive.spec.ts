import { CusDirectiveDirective } from './cus-directive.directive';

describe('CusDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new CusDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
