import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appCusDirective]'
})
export class CusDirectiveDirective {
  @HostBinding('style.background') background = 'none'; 
  @HostListener('mouseenter') onEnter() {
   this.background ='blue';
  }
    @HostListener('mouseleave') onLeave() {
   this.background ='none';
  }
  constructor() { }

}
