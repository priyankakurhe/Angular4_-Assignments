import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CusDirectiveDirective } from '../cus-directive.directive';
import { NewcompComponent } from '../newcomp/newcomp.component';
import { BrowserModule } from '@angular/platform-browser';

@NgModule({
  declarations: [CusDirectiveDirective, NewcompComponent],
  imports: [
    CommonModule,
    BrowserModule
  ],
  providers:[],
  bootstrap:[NewcompComponent]
})
export class MyModuleModule { }
